#ifndef STREAMERTHREAD_H
#define STREAMERTHREAD_H

class StreamerThread
{
public:
    StreamerThread();
};

#endif // STREAMERTHREAD_H
