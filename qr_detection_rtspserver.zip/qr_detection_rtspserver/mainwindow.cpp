#include "mainwindow.h"
#include "ui_mainwindow.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{


    ui->setupUi(this);

    qRegisterMetaType<cv::Mat>("cv::Mat&");
    capturer = new Capturer;
    capturer->moveToThread(&capturerThread);
    connect(&capturerThread, &QThread::finished, capturer, &QObject::deleteLater);
    connect(this, &MainWindow::startOperation, capturer, &Capturer::capture);
    this-> StartCapturer();

    streamer = new Streamer;
    streamer->moveToThread(&streamerThread);
    connect(&streamerThread, &QThread::finished, streamer, &QObject::deleteLater);
    connect(this, &MainWindow::startOperation, streamer, &Streamer::startStreamer);
    this-> StartStreamer();
    qRegisterMetaType<cv::Mat>("cv::Mat&");
    connect(capturer, &Capturer::imReady, streamer, &Streamer::updateFrame);


    //connect(streamer, &Streamer::resultReady2, this, &MainWindow::handelResult2);


}

MainWindow::~MainWindow()
{
    delete ui;

}
void MainWindow::StartCapturer(){
    capturerThread.start();
    Q_EMIT startOperation();

}
void MainWindow::StartStreamer(){
    streamerThread.start();
    Q_EMIT startOperation();

}
