#include "streamerthread.h"

StreamerThread::StreamerThread() {}
