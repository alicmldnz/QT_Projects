#include "capturer.h"
#include <opencv2/opencv.hpp>
#include <zbar.h>
#include <QThread>
Capturer::Capturer(QObject *parent)
    : QObject{parent} {}


Capturer::~Capturer()
{
    if (camera) {
        camera->stop();
        delete camera;
    }
    if (probe) {
        delete probe;
    }


}

void Capturer::capture(){
    qDebug() << "capture function";
    probe = new QVideoProbe;
    camera = new QCamera(QCamera::availableDevices().at(1));
    // Connect the videoFrameProbed signal to the processFrame slot
    QObject::connect(probe, &QVideoProbe::videoFrameProbed, this, [this](const QVideoFrame &frame) {
        this->processFrame(frame);
    });
    probe->setSource(camera);

    camera->start();
    qDebug() << "camera has started";
}
void Capturer::processFrame(const QVideoFrame &frame)
{
    if (!frame.isValid()) {
        qDebug() << "Frame is not valid";
        return;
    }

    QVideoFrame cloneFrame(frame);
    cloneFrame.map(QAbstractVideoBuffer::ReadOnly);

    // Convert QVideoFrame to cv::Mat
    cv::Mat im(cloneFrame.height(), cloneFrame.width(), CV_8UC1, (void*)cloneFrame.bits(), cloneFrame.bytesPerLine());
    cv::Mat imGray = im;
    cv::cvtColor(im, im, cv::COLOR_GRAY2RGB);

    // Create zbar scanner
    zbar::ImageScanner scanner;
    scanner.set_config(zbar::ZBAR_NONE, zbar::ZBAR_CFG_ENABLE, 1);

    int width = imGray.cols;
    int height = imGray.rows;
    uchar *raw = (uchar *)imGray.data;

    // Wrap image data in a zbar image
    zbar::Image zbarImage(width, height, "Y800", raw, width * height);
    int n = scanner.scan(zbarImage);

    if (n > 0) {
        for (zbar::Image::SymbolIterator symbol = zbarImage.symbol_begin(); symbol != zbarImage.symbol_end(); ++symbol) {
            std::string myData = symbol->get_data();
            qDebug() << "QR Code Detected:" << QString::fromStdString(myData);

            std::vector<cv::Point> points;
            for (int i = 0; i < symbol->get_location_size(); ++i) {
                int x = symbol->get_location_x(i);
                int y = symbol->get_location_y(i);
                points.emplace_back(cv::Point(x, y));
            }
            cv::putText(im, //target image
                        "QRCODE!", //text
                        cv::Point(im.cols, im.rows / 2), //top-left position
                        cv::FONT_HERSHEY_DUPLEX,
                        1.0,
                        CV_RGB(255, 150, 0), //font color
                        2);

            std::vector<std::vector<cv::Point>> contours;
            contours.push_back(points);
            cv::polylines(im, contours, true, cv::Scalar(0, 0, 0), 2);


            // Update the Streamer with the current frame
            //streamer-> updateFrame(im);
            Q_EMIT imReady(im);

        }
    } else {
        qDebug() << "No QR Code Detected";
        Q_EMIT imReady(im);
        //streamer-> updateFrame(im);
    }

    cloneFrame.unmap();
}
