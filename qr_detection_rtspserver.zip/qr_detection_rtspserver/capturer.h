#ifndef CAPTURER_H
#define CAPTURER_H
#include <QObject>
#include <QVideoProbe>
#include <QCamera>
#include "streamer.h"
#include <opencv2/opencv.hpp>
class Capturer : public QObject
{
    Q_OBJECT

public:
    explicit Capturer(QObject *parent = nullptr);
    ~Capturer();
    void Operation();
public Q_SLOTS:
    void capture();
    void processFrame(const QVideoFrame &frame);
Q_SIGNALS:
    void imReady(cv::Mat &im);

private:
    QVideoProbe *probe;
    QCamera *camera;

};

#endif // CAPTURER_H
