#include "test.h"

test::test(QObject *parent)
    : QObject{parent}
{}
