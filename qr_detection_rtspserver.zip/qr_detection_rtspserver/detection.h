#ifndef DETECTION_H
#define DETECTION_H
#include <zbar.h>
#include <QObject>

class Detection : public QObject
{
    Q_OBJECT
public:
    explicit Detection(QObject *parent = nullptr);



};

#endif // DETECTION_H
